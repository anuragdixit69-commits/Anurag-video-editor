plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.anurag.videoeditor"
    compileSdk = 35
    defaultConfig { applicationId = "com.anurag.videoeditor"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("com.google.guava:guava:33.3.1-android")
}
