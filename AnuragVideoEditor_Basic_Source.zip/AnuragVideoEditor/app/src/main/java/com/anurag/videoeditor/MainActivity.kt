package com.anurag.videoeditor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File

@androidx.annotation.OptIn(UnstableApi::class)
class MainActivity : Activity() {
    private val clips = mutableListOf<Uri>()
    private var soundtrack: Uri? = null
    private lateinit var status: TextView
    private lateinit var clipList: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var captionInput: EditText
    private var transformer: Transformer? = null
    private var workingFile: File? = null
    private val chooseClips = 101
    private val chooseAudio = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(17, 20, 29))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, 10, 0, 10)
        }
        fun field(hintText: String, default: String = ""): EditText = EditText(this).apply {
            hint = hintText; setText(default); setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            root.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        fun button(s: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = s; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(label("ANURAG VIDEO EDITOR", 25f))
        root.addView(label("Basic • 9:16 • MP4 • 1080p target", 14f))
        button("1. Add videos (in merge order)") { pick("video/*", chooseClips, true) }
        clipList = label("No videos selected")
        root.addView(clipList)
        button("Clear videos") { clips.clear(); updateClips() }
        root.addView(label("Trim first clip (milliseconds; 0 = start / end)"))
        startInput = field("Start ms", "0")
        endInput = field("End ms (0 = original end)", "0")
        button("2. Choose background music") { pick("audio/*", chooseAudio, false) }
        button("Remove music") { soundtrack = null; status.text = "Music removed" }
        root.addView(label("3. Overlay text (also includes fixed watermark)"))
        captionInput = field("Optional caption", "")
        button("4. Export to Movies") { export() }
        status = label("Ready. Select one or more video clips.")
        root.addView(status)
        root.addView(label("Note: Output dimensions depend on source and device encoder support. Portrait clips are recommended for 1080×1920.", 12f))
    }

    private fun pick(mime: String, request: Int, multiple: Boolean) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = mime
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        }, request)
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { if (!uris.contains(it)) uris.add(it) }
        uris.forEach { runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        if (requestCode == chooseClips) { clips.addAll(uris); updateClips() }
        if (requestCode == chooseAudio) { soundtrack = uris.firstOrNull(); status.text = "Background music selected" }
    }
    private fun updateClips() { clipList.text = if (clips.isEmpty()) "No videos selected" else "${clips.size} video(s) selected, in order" }

    private fun export() {
        if (clips.isEmpty()) { status.text = "Please select at least one video"; return }
        val from = startInput.text.toString().toLongOrNull() ?: 0L
        val to = endInput.text.toString().toLongOrNull() ?: 0L
        if (from < 0 || to < 0 || (to > 0 && to <= from)) { status.text = "Invalid trim range"; return }
        status.text = "Exporting… please keep this screen open"
        try {
            val caption = captionInput.text.toString().trim()
            val watermark = SpannableString(if (caption.isEmpty()) "Anurag Video Editor" else "$caption   •   Anurag Video Editor").apply {
                setSpan(ForegroundColorSpan(Color.WHITE), 0, length, 0)
                setSpan(RelativeSizeSpan(0.8f), 0, length, 0)
            }
            val videoItems = clips.mapIndexed { index, uri ->
                val media = MediaItem.Builder().setUri(uri).apply {
                    if (index == 0 && (from > 0 || to > 0)) {
                        setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().apply {
                            setStartPositionMs(from)
                            if (to > 0) setEndPositionMs(to)
                        }.build())
                    }
                }.build()
                val videoEffects = listOf(
                    Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT),
                    Presentation.createForHeight(1920),
                    OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(watermark)))
                )
                EditedMediaItem.Builder(media).setEffects(Effects(emptyList(), videoEffects)).build()
            }
            val videoSequence = EditedMediaItemSequence.Builder(videoItems).build()
            val sequences = mutableListOf(videoSequence)
            soundtrack?.let { audioUri ->
                val music = EditedMediaItem.Builder(MediaItem.fromUri(audioUri))
                    .setRemoveVideo(true).build()
                sequences.add(EditedMediaItemSequence.Builder(listOf(music)).setIsLooping(true).build())
            }
            val composition = Composition.Builder(sequences).build()
            val out = File(cacheDir, "anurag_export_${System.currentTimeMillis()}.mp4")
            workingFile = out
            transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        runOnUiThread { saveToMovies(out) }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        runOnUiThread { status.text = "Export failed: ${exportException.message}" }
                    }
                }).build()
            transformer!!.start(composition, out.absolutePath)
        } catch (e: Exception) { status.text = "Could not start export: ${e.message}" }
    }
    private fun saveToMovies(file: File) {
        try {
            val name = "Anurag_${System.currentTimeMillis()}.mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnuragVideoEditor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("MediaStore insert failed")
            contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                ?: error("Unable to open output")
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            status.text = "Saved successfully: Movies/AnuragVideoEditor/$name"
            file.delete()
        } catch (e: Exception) { status.text = "Export complete, but save failed: ${e.message}" }
    }
    override fun onDestroy() { transformer?.cancel(); super.onDestroy() }
}
