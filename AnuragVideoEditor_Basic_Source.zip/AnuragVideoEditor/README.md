# Anurag Video Editor — Basic Android project

**Status:** Source-code starter project; not compiled or tested in this environment. No APK is included.

## Intended features
- Select one or more videos (selection order = merge order)
- Trim the first clip using start/end milliseconds
- Add optional looping music (original clip audio is retained)
- Add optional text plus mandatory `Anurag Video Editor` watermark
- 9:16 portrait layout, target height 1920 pixels, H.264/AAC MP4
- Export to phone's `Movies/AnuragVideoEditor` folder using MediaStore
- English interface; Android 8.0+ (API 26+)

## Build instructions
1. Install current Android Studio and Android SDK 35; use JDK 17.
2. Open the **AnuragVideoEditor** folder (the one containing `settings.gradle.kts`).
3. Allow Gradle to sync/download Android Gradle Plugin, Kotlin, and AndroidX Media3 libraries.
4. Connect an Android device with USB debugging, select it, and press **Run**.
5. To make an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Debug APK will normally be at `app/build/outputs/apk/debug/app-debug.apk` after a successful build.
7. For public distribution, generate a signed release APK/AAB via **Build > Generate Signed Bundle / APK**.

## Known limitations and cautions
- The source has not been compiled or device-tested here; dependency API changes may require fixes during Gradle sync/build.
- 1080×1920 is a **target**, not a guarantee; encoder and input constraints may affect resolution or export success.
- The watermark/text are static overlays; there is no text-positioning UI yet.
- Trimming currently applies to the first clip only; audio is not mixed with a volume slider.
- Clip selection order may vary by document provider; no drag-to-reorder UI.
- Some codecs, variable frame rates, HDR sources, or long videos may fail on certain devices.
- Keep the app open during export; background export is not implemented.
- No thumbnail preview, undo, transitions, filters, or full timeline in this first version.
- If Gradle sync fails, verify Google/Maven Central access and use an Android Studio release supporting AGP 8.7.3.

## Implementation
Kotlin + AndroidX Media3 Transformer, using Android's document picker and MediaStore (no broad storage permission needed).
